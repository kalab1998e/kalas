#include "matrix.h"
#include "ringQueue.h"

BlockedMatrix *blockedMatrixNew( Matrix *a, int blkRow, int blkCol)
{}

void blockedMatrixDelete( BlockedMatrix *a)
{}



