#include <sys/time.h>
#include <f77blas.h>
#include "matrix.h"
#include "kalas.h"
#include "kalasState.h"
#include "kadbg.h"

int main(void)
{
  KalasState *state;
  Matrix *a, *b, *c1, *c2;
  typeKind type = KALAS_DOUBLE;
  int am, an, bm, bn, cm, cn;
  float falpha = 1.0, fbeta = 0.0;
  double dalpha = 1.0, dbeta = 0.0, e;
  char ta = 'N', tb = 'N';
  struct timeval t;
  double ts, te;

  dbgMsg("");
  state = kalasStateNew();
 
  dbgMsg("");
  for ( int i = 4; i <= 4096; i += 4) {
    dbgMsg("");
    am = an = bm = bn = cm = cn = i;
    dbgMsg("");
    a = matrixNew( am, an, an, type, 1);
    dbgMsg("");
    b = matrixNew( bm, bn, bn, type, 1);
    dbgMsg("");
    c1 = matrixNew( cm, cn, cn, type, 0);
    dbgMsg("");
    c2 = matrixNew( cm, cn, cn, type, 0);
    
    dbgMsg("");
    gettimeofday( &t, NULL);
    dbgMsg("");
    ts = t.tv_sec + (double)(t.tv_usec) / 1000000.0;
    dbgMsg("");
    switch (type) {
    case KALAS_FLOAT:
			dbgMsg("");
      sgemm_( &ta, &tb, &cm, &cn, &an, &falpha, a->elm, &(a->ld),
              b->elm, &(b->ld), &fbeta,
              c1->elm, &(c1->ld));
			dbgMsg("");
      break;
    case KALAS_DOUBLE:
			dbgMsg("");
      dgemm_( &ta, &tb, &cm, &cn, &an, &dalpha, a->elm, &(a->ld),
              b->elm, &(b->ld), &dbeta,
              c1->elm, &(c1->ld));
			dbgMsg("");
      break;
    }
    dbgMsg("");
    gettimeofday( &t, NULL);
    dbgMsg("");
    te = t.tv_sec + (double)(t.tv_usec) / 1000000.0;
    dbgMsg("");
    printf( "%d %f s %f GFlops ", am, (te - ts),
            (double)am * (double)am * (double)am * 2.0
            / ( te - ts) / 1000000000.0);

    dbgMsg("");
    gettimeofday( &t, NULL);
    dbgMsg("");
    ts = t.tv_sec + (double)(t.tv_usec) / 1000000.0;
    dbgMsg("");
    switch (type) {
    case KALAS_FLOAT:
			dbgMsg("");
      kalasSgemm( state, 'N', 'N', cm, cn, an, 1.0, a->elm, a->ld,
                  b->elm, b->ld, 0.0,
                  c2->elm, c2->ld);
			dbgMsg("");
      break;
    case KALAS_DOUBLE:
			dbgMsg("");
      kalasDgemm( state, 'N', 'N', cm, cn, an, 1.0, a->elm, a->ld,
                  b->elm, b->ld, 0.0,
                  c2->elm, c2->ld);
			dbgMsg("");
      break;
    }
    dbgMsg("");
    gettimeofday( &t, NULL);
    dbgMsg("");
    te = t.tv_sec + (double)(t.tv_usec) / 1000000.0;
    dbgMsg("");
    printf( "%f s %f GFlops ", (te - ts),
            (double)am * (double)am * (double)am * 2.0
            / ( te - ts) / 1000000000.0);

    dbgMsg("");
    e = matrixCalcDiff( c1, c2);
    printf( "%e\n", e);

    dbgMsg("");
    matrixDelete( a);
    dbgMsg("");
    matrixDelete( b);
    dbgMsg("");
    matrixDelete( c1);
    dbgMsg("");
    matrixDelete( c2);
  }
  dbgMsg("");
  kalasStateDelete( state);
}

